import React from "react";
import { StyleSheet, Text, View } from "react-native";

const PaymentStatus = () => {
  return (
    <View style={styles.root}>
      <Text style={styles.text}>This is payment status loader screen</Text>
    </View>
  );
};

export default PaymentStatus;

const styles = StyleSheet.create({
  root: {
    flex: 1,
    justifyContent: "center",
    alignItems: "center",
    backgroundColor: "white",
  },
  text: {
    fontSize: 17,
    fontWeight: "700",
    textAlign: "center",
  },
});
