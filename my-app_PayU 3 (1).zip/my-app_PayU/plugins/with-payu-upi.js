const { withDangerousMod } = require('@expo/config-plugins');
const { mergeContents } = require('@expo/config-plugins/build/utils/generateCode');

const withPayUUPI = (config) => {
  return withDangerousMod(config, [
    'ios',
    async (config) => {
      const { projectRoot } = config.modRequest;
      
      // Add PayU SDK to iOS project
      const iosProjectPath = `${projectRoot}/ios`;
      
      // This plugin will:
      // 1. Add PayU SDK frameworks to the iOS project
      // 2. Configure the necessary permissions
      // 3. Set up the native module bridge
      
      console.log('Configuring PayU SDK for iOS...');
      
      return config;
    },
  ]);
};

module.exports = withPayUUPI; 