/* eslint-disable import/no-unresolved */
import { router } from "expo-router";
import { sha512 } from 'js-sha512';
import React, { useState } from "react";
import { Alert, Pressable, StyleSheet, Text } from "react-native";

// PayU SDK import with proper error handling
let PayUUPI: any = null;
let isNativeModuleAvailable = false;

try {
  const { NativeModules } = require('react-native');
  PayUUPI = NativeModules.PayUUPI;
  
  // Check if the native module is available
  if (PayUUPI && typeof PayUUPI.makeUPIPayment === 'function') {
    isNativeModuleAvailable = true;
    console.log("PayU Native Module available with makeUPIPayment");
  } else if (PayUUPI && typeof PayUUPI.multiply === 'function') {
    console.log("PayU Native Module available but makeUPIPayment not found");
  } else {
    console.log("PayU Native Module not available in Expo Go");
  }
} catch (error) {
  console.log("PayU SDK not available in Expo Go:", error);
}

const PayUButton = () => {
  const [showAlert, setShowAlert] = useState(false);
  const [transactionId, setTransactionId] = useState(
    new Date().getTime().toString(),
  );
  const [key, setKey] = useState('MerchantKey');
  const [merchantSalt, setMerchantSalt] = useState(
    'YourSalt',
  );

  const calculateHash = (data: string) => {
    console.log('hashData' + JSON.stringify(data));
    var result = sha512(data);
    console.log(result);
    return result;
  };

  const displayAlert = (title: string, value: string) => {
    if (showAlert == false) {
      console.log('displayAlert ' + title + ' ' + value);
      setShowAlert(true);
      Alert.alert(title, value);
    }
    setShowAlert(false);
  };

  const handlePayment = async () => {
    var payUPaymentParams = {
      payu_payment_params: {
        key: key, //merchant key
        transaction_id: transactionId, // i.e. new Date().getTime().toString()
        amount: "1.0", // amount in Double format
        product_info: 'Medicine',
        first_name: 'Ram',
        email: 'admin@gmail.com',
        phone: '9774986108',
        ios_surl: 'https://aawb.com/success',
        ios_furl: 'https://aawb.com/_payment/fail',
        android_surl: 'https://aawb.com/_payment/success',
        android_furl: 'https://aawb.com/_payment/fail',
        environment: "0",
        post_url: 'https://secure.payu.in/_payment', // "https://secure.payu.in" for production, "https://test.payu.in" for Stage
        payment_mode: 'INTENT',
        intent_app: 'paytm', // For IOS
        hashes: {
          payment: calculateHash(
            key +
            '|' +
            transactionId +
            '|' +
            "1.0" +
            '|Medicine|Ram|admin@gmail.com|||||||||||' +
            merchantSalt,
          )
        },
        additional_param: {
          udf1: '',
          udf2: '',
          udf3: '',
          udf4: '',
          udf5: '',
        },
      },
    };

    console.log("GenericIntent" + JSON.stringify(payUPaymentParams));
    
    // Check if PayU SDK is available with makeUPIPayment
    if (!isNativeModuleAvailable) {
      console.log("PayU SDK not available - simulating payment flow");
      displayAlert('Development Mode', 'PayU SDK not available in Expo Go. This would trigger payment in production build.');
      // Simulate payment flow for development
      setTimeout(() => {
        displayAlert('Payment Simulation', 'Payment parameters logged successfully. In production build, this would open PayU payment.');
        router.replace(`/payment-status`);
      }, 2000);
      return;
    }

      PayUUPI.makeUPIPayment(
        payUPaymentParams,
        error => {
          console.log('React: UPI Error:', error);
          //handlePaymentCompletion(error, true);
          displayAlert('Payment Error', JSON.stringify(error));
        },
        result => {
          console.log('React:UPI Success:', result);
          //handlePaymentCompletion(result);
          displayAlert('Payment Success', JSON.stringify(result));
        },
      );
  };

  const handlePaymentCompletion = (response: any, isError: boolean = false) => {
    console.log(`PayU ${isError ? "error" : "result"}`, response);
    router.replace(`/payment-status`);
  };

  return (
    <Pressable onPress={handlePayment} style={styles.button}>
      <Text style={styles.text}>PayU Button</Text>
    </Pressable>
  );
};

export default PayUButton;

const styles = StyleSheet.create({
  button: {
    borderWidth: 2,
    height: 50,
    backgroundColor: "#39FF14",
    justifyContent: "center",
    alignItems: "center",
    borderRadius: 8,
  },
  text: {
    fontSize: 17,
    fontWeight: "700",
  },
});
