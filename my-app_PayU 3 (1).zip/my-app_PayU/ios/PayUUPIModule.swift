import Foundation
import React

@objc(PayUUPIModule)
class PayUUPIModule: RCTEventEmitter {
  
  override init() {
    super.init()
  }
  
  @objc
  override static func requiresMainQueueSetup() -> Bool {
    return true
  }
  
  override func supportedEvents() -> [String]! {
    return ["PayUPaymentSuccess", "PayUPaymentFailure", "PayUPaymentError"]
  }
  
  @objc
  func makeUPIPayment(_ params: NSDictionary, 
                      resolver: @escaping RCTPromiseResolveBlock, 
                      rejecter: @escaping RCTPromiseRejectBlock) {
    
    DispatchQueue.main.async {
      // Here you would integrate with the actual PayU iOS SDK
      // For now, we'll simulate the payment flow
      
      guard let paymentParams = params["payu_payment_params"] as? [String: Any] else {
        rejecter("INVALID_PARAMS", "Invalid payment parameters", nil)
        return
      }
      
      // Log the payment parameters
      print("PayU Payment Parameters:", paymentParams)
      
      // Simulate payment processing
      DispatchQueue.main.asyncAfter(deadline: .now() + 2.0) {
        // Simulate success callback
        let result: [String: Any] = [
          "status": "success",
          "transaction_id": paymentParams["transaction_id"] as? String ?? "",
          "message": "Payment processed successfully"
        ]
        
        self.sendEvent(withName: "PayUPaymentSuccess", body: result)
        resolver(result)
      }
    }
  }
  
  @objc
  func multiply(_ a: NSNumber, b: NSNumber, resolver: RCTPromiseResolveBlock, rejecter: RCTPromiseRejectBlock) {
    resolver(a.doubleValue * b.doubleValue)
  }
} 